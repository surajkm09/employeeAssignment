package com.accenture.assignment.employeemangementsystem.userinterfacelayer;

import com.accenture.assignment.employeemangementsystem.Util;
import com.accenture.assignment.employeemangementsystem.servicelayer.ServiceLayer;

public class EmployeeManagementSystem {

	public static void main(String[] args) {
		
		ServiceLayer serviceLayer = new ServiceLayer(); 
		while(true ) 
		{
			System.out.println("enter you choice\n"+
			"1.add employee\n"+
			"2.get all employees\n"+ 
			"3.update a particular employee \n"+
			"4.delete employee using employee ID\n"+
			"5.display employees sorted by id and salary\n"+ 
			"6.display employees sorted by name \n"+
			"7.write all employee details to a file "+
			"8.exit");
			
			
			switch(Util.inputInt())
			{
			case 1 : 
				serviceLayer.addEmployee();
				break ; 
			case 2 : 
				serviceLayer.displayAllEmployees();
				break ; 
			case 3 : 
				serviceLayer.updateEmployee();
				break ; 
			case 4 : 
				serviceLayer.deleteEmployee();
				break ; 
			case 5 :
				serviceLayer.sortEmployeesByIdAndSalary();
				break ; 
			case 6 : 
				serviceLayer.sortEmployeesByName();
				break ; 
			case 7 : 
				serviceLayer.writeEmployeesToFile();
				break  ;
			case 8: 
				System.out.println("bye !see you soon .");
				return  ; 
			default : 
				System.out.println("enter a valid option");
				break;
			
			}
			
		}

	}

}
