package com.accenture.assignment.employeemangementsystem;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Util {
	
	static private  Scanner input ; 
	static {
		 input = new Scanner(System.in);
		 
	}
	
	public static int inputInt()
	{
		while(true)
		{
			try {
				
				int result = input.nextInt();
				input.nextLine();
				return result ; 
				
			}
			catch(InputMismatchException e)
			{
				System.out.println("Expecting an integer type input  Please try again");
				input.nextLine();
			}
		}
		
		 
	}
	public static String inputString()
	{
		
		return input.nextLine(); 
	}
	@Override
	protected void finalize() throws Throwable {
		input.close();
		super.finalize();
	}

}
