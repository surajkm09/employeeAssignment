package com.accenture.assignment.employeemangementsystem.servicelayer;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

import com.accenture.assignment.employeemangementsystem.Employee;
import com.accenture.assignment.employeemangementsystem.EmployeeIdAndSalarySort;
import com.accenture.assignment.employeemangementsystem.EmployeeNameSort;
import com.accenture.assignment.employeemangementsystem.Util;
import com.accenture.assignment.employeemangementsystem.dataaccesslayer.DataAccessLayer;

public class ServiceLayer implements IServiceLayer {

	ArrayList<Employee> employees ;
	DataAccessLayer dataAccessLayer = new DataAccessLayer();
	@Override
	public void addEmployee() {
		Employee employee = new Employee(); 
		System.out.println("--------------------Employee Entry ------------------------");
		System.out.println("Enter the employee id ");
		employee.setId(Util.inputInt());
		System.out.println("Enter Employee Name ");
		employee.setName(Util.inputString());
		System.out.println("Enter Employee Address");
		employee.setAddress(Util.inputString());
		System.out.println("Enter salary ");
		employee.setSalary(Util.inputInt());
		System.out.println("Enter phone number ");
		employee.setPhoneNumber(Util.inputInt());
		if(!dataAccessLayer.insertEmployee(employee))
		{
			System.out.println("Record insertion failed ! please try again ");
			
			
		}
		else
		{
			System.out.println("Record inserted succesfully !");
		}
		System.out.println("--------------------Employee Entry ------------------------");
		

	}

	private void display(ArrayList<Employee> employees) 
	{
		System.out.println("----------------------employees----------------------");
		if(employees == null || employees.size()==0 )
		{
			System.out.println(" shit ! No data retured to display .");
		}
		else 
		{
			for (Employee employee : employees) {
			
			System.out.println("Employee ID:"+employee.getId() +"\t"+"Employee Name:"
					+ employee.getName()+"\t" +"Employee Address:" +employee.getAddress()+
					"Employee salary:"+ employee.getSalary()+"\t" +"Employee phone:"+employee.getPhoneNumber());
			}
		}
	
		System.out.println("----------------------employees----------------------");

	}
	@Override
	public void displayAllEmployees() {
		employees = dataAccessLayer.getEmployees();
		
		System.out.println("----------------------employees----------------------");
		if(employees == null || employees.size()==0 )
		{
			System.out.println(" shit ! No data retured to display .");
		}
		else 
		{
			for (Employee employee : employees) {
			
			System.out.println("Employee ID:"+employee.getId() +"\t"+"Employee Name:"
					+ employee.getName()+"\t" +"Employee Address:" +employee.getAddress()+
					"Employee salary:"+ employee.getSalary()+"\t" +"Employee phone:"+employee.getPhoneNumber());
			}
		}
	
		System.out.println("----------------------employees----------------------");

	}

	@Override
	public void updateEmployee() {
		Employee employee = new Employee(); 
		System.out.println("--------------------Employee updation ------------------------");
		System.out.println("Enter the employee id ");
		employee.setId(Util.inputInt());
		System.out.println("Enter Employee Name ");
		employee.setName(Util.inputString());
		System.out.println("Enter Employee Address");
		employee.setAddress(Util.inputString());
		System.out.println("Enter salary ");
		employee.setSalary(Util.inputInt());
		System.out.println("Enter phone number ");
		employee.setPhoneNumber(Util.inputInt());
		if(!dataAccessLayer.updateEmployee(employee))
		{
			System.out.println("Record upadate failed ! please try again ");
			
		}
		else
		{
			System.out.println("Record updated succesfully !");
		}
		System.out.println("--------------------Employee updation ------------------------");

	}

	@Override
	public void deleteEmployee() {
		System.out.println("--------------------Employee deletion ------------------------");
		System.out.println("Enter the employee id ");
		if(!dataAccessLayer.deleteEmployee(Util.inputInt()))
		{
			System.out.println("Record deletion failed or no records deleted ! please try again ");
			 
		}
		else
		{
				System.out.println("Record deleted succesfully !");
		}
		System.out.println("--------------------Employee deletion ------------------------");

		

	}

	@Override
	public void sortEmployeesByName() {
		employees = dataAccessLayer.getEmployees(); 
		Collections.sort(employees, new EmployeeNameSort());
		display(employees);
	
	}

	@Override
	public void sortEmployeesByIdAndSalary() {
		employees = dataAccessLayer.getEmployees(); 
		Collections.sort(employees, new EmployeeIdAndSalarySort());
		display(employees);

	}

	@Override
	public void writeEmployeesToFile() {
		employees = dataAccessLayer.getEmployees(); 
		
		if(employees == null )
		{
			System.out.println("noting to output to file !!");
			return  ;
		}
		System.out.println("-----starting write process------");
		File file = new File("output.txt") ; 
		try {
			if(file.createNewFile())
			{
				System.out.println("created new file output.txt");
			}
			else
			{
				System.out.println("overwriting output.txt");
			}
		}
		catch(IOException e )
		{
			System.out.println("error while creating file ");
		}
		try(FileWriter fileWriter = new FileWriter(file);) {
		
		for (Employee employee : employees) {
			fileWriter.write(employee.getId()+";"+employee.getName()+";"+employee.getAddress()+";"+
					+employee.getSalary()+";"+employee.getPhoneNumber()+"\n");
			
		}
		System.out.println(" records Succesfully iserted into file ! ");
		}
		catch(IOException e) 
		{
			
			System.out.println("Error while writing to file !");
			e.printStackTrace();
		}
		System.out.println("-----ending  write process------");

	}
	
	public static void main(String args[]) 
	{
		ServiceLayer serviceLayer = new ServiceLayer() ; 
		serviceLayer.writeEmployeesToFile();
	}

}
