package com.accenture.assignment.employeemangementsystem.servicelayer;

public interface IServiceLayer {
	
	

	void addEmployee(); 
	void displayAllEmployees();
	void updateEmployee(); 
	void deleteEmployee(); 
	void sortEmployeesByName(); 
	void sortEmployeesByIdAndSalary();
	void writeEmployeesToFile(); 
	
	
}
