package com.accenture.assignment.employeemangementsystem.dataaccesslayer;
import java.sql.* ; 
import java.util.ArrayList;
import com.accenture.assignment.employeemangementsystem.Employee;

public class DataAccessLayer implements IDataAccessLayer {

	
	Connection connection  = null ; 
	String dburl ="jdbc:mysql://localhost/employee" ;
	String userName ="root"; 
	String password ="root1770"; 
	
	public DataAccessLayer() {
		
		try {
			
			connection = DriverManager.getConnection(dburl, userName, password);
			System.out.println("Conected succesfully to db! cheers");
		}
		catch(SQLException e )
		{
			System.out.println("Error while connecting to database ! please try again ");
			e.printStackTrace();
		}
		
	}
	@Override
	public boolean insertEmployee(Employee employee) {
		
		String insertQuery= "INSERT INTO EMPLOYEE values(?,?,?,"
				+ "?,?)";
		try
		{
			PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);
			preparedStatement.setInt(1, employee.getId());
			preparedStatement.setString(2, employee.getName());
			preparedStatement.setString(3, employee.getAddress());
			preparedStatement.setInt(4, employee.getSalary());
			preparedStatement.setInt(5, employee.getPhoneNumber());
			int rowsInserted = preparedStatement.executeUpdate();
			return rowsInserted == 0 ?false : true ; 
		}
		catch(SQLException e ) 
		{
			System.out.println("Error While inserting record");
			e.printStackTrace();
			return false ; 
		}
		
	}

	
	@Override
	public ArrayList<Employee> getEmployees() {
		ArrayList<Employee> employees = new ArrayList<>();
		
		
		try 
		{
			Statement statement = connection.createStatement() ;
			ResultSet resultSet = statement.executeQuery(GET_ALL_EMPLOYEES);
			while(resultSet.next())
			{
				employees.add(new Employee(resultSet.getInt(1), resultSet.getString(2),resultSet.getString(3), resultSet.getInt(4), resultSet.getInt(5)));
			
			}
		}
		catch(SQLException e ) 
		{
			System.out.println("Error while accessing all emplpoyees!!");
			e.printStackTrace();
		}
		
		return employees  ;
		
	}

	@Override
	public boolean updateEmployee(Employee employee) {
		
		String updateQuery= "UPDATE EMPLOYEE SET id=? ,name=? , address= ?,"
				+ "salary=?,phone=? where id =?";
		try
		{
			PreparedStatement preparedStatement = connection.prepareStatement(updateQuery);
			preparedStatement.setInt(1, employee.getId());
			preparedStatement.setString(2, employee.getName());
			preparedStatement.setString(3, employee.getAddress());
			preparedStatement.setInt(4, employee.getSalary());
			preparedStatement.setInt(5, employee.getPhoneNumber());
			preparedStatement.setInt(6, employee.getId());
			int rowsUpdated = preparedStatement.executeUpdate();
			return rowsUpdated == 0 ?false : true ; 
		}
		catch(SQLException e ) 
		{
			System.out.println("Error While updating record");
			e.printStackTrace();
			return false ; 
		}
		
	}

	@Override
	public boolean deleteEmployee(int employeeId) {
		
		try {
		String deleteQuery= "DELETE FROM employee WHERE id=?"; 
		PreparedStatement preparedStatement = connection.prepareStatement(deleteQuery);
		preparedStatement.setInt(1, employeeId);
		int rowsDeleted = preparedStatement.executeUpdate();
		return rowsDeleted ==0 ? false: true ;  
		}
		catch(SQLException e )
		{
			System.out.println("Error while deleting record");
			return false ; 
		}
		
	}
	
	@Override
	protected void finalize() throws Throwable {
		if(connection!=null)
		{
			connection.close();
		}
		
		super.finalize();
	}
	
	

}
