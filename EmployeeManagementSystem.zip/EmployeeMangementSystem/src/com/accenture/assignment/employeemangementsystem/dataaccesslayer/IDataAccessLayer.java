package com.accenture.assignment.employeemangementsystem.dataaccesslayer;

import java.util.ArrayList;

import com.accenture.assignment.employeemangementsystem.Employee;

public interface IDataAccessLayer {
	
	static String  GET_ALL_EMPLOYEES ="SELECT * FROM employee;" ; 
	boolean insertEmployee(Employee employee );
	ArrayList<Employee> getEmployees();
	boolean updateEmployee(Employee employee);
	boolean deleteEmployee(int employeeId); 

}
